#include<iostream>
using namespace std;
struct student{
	string firstname;
	string lastname;
	int rollnumber;
	float marks;
	
	void displaystudentinfo(){
		cout<<"fullname:"<<firstname<<" "<<lastname<<endl;
		cout<<"marks:"<<marks<<endl;
	}
};
int main(){
	int n;
	cout<<"enter number of student";
	cin>>n;
	student students [n];
	for(int i=0; i<n; i++){
	cout<<"student"<<i+1<<endl;
	cout<<"firstname:";
	cin>>students [i].firstname;
	cout<<"lastname:";
	cin>>students [i].lastname;
	cout<<"rollnumber:";
	cin>>students [i].rollnumber;
	cout<<"marks:";
	cin>>students [i].marks;
	}
	for(int i= 0;i<n;i++){
		students [i].displaystudentinfo();
	}
	return 0;
}
