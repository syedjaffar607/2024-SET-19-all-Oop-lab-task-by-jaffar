#include <iostream>
#include <fstream>
using namespace std;

int main()
{
    ofstream writeFile("notes.txt");

    writeFile << " what is your name." << endl;
    writeFile << "how are you." << endl;
    writeFile << "i am fine." << endl;

    writeFile.close();

    ifstream readFile("notes.txt");
    string line;

    cout << "File Contents:" << endl;

    while (getline(readFile, line))
    {
        cout << line << endl;
    }

    readFile.close();
    
    ofstream appendFile("notes.txt", ios::app);

    appendFile << "Name: jaffar" << endl;
    appendFile << "Roll No: 123" << endl;

    appendFile.close();

    cout << "\nData appended successfully." << endl;

    return 0;
}