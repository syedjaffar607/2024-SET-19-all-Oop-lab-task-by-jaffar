#include <iostream>
using namespace std;

class Vehicle {
public:
    Vehicle(string type) {
        cout << "Vehicle Constructor Called: " << type << endl;
    }
};
class Car : public Vehicle {
public:
    Car(string type, string brand)
        : Vehicle(type) 
    {
        cout << "Car Constructor Called: " << brand << endl;
    }
};

class ElectricCar : public Car {
public:
    ElectricCar(string type, string brand, string battery)
        : Car(type, brand) 
    {
        cout << "ElectricCar Constructor Called: Battery " << battery << endl;
    }
};

int main() {
    ElectricCar ec("4-Wheeler", "Tesla", "100 kWh");

    return 0;
}
